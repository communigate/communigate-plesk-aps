<?php
return array (
  'template' => 'default',
  'baseClass' => 'Controller',
  'actions' => 'index create update delete subscribe unsubscribe',
);
