<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - Mailing Lists';
$this->breadcrumbs=array(
	'Mailing Lists',
);
?>
<h1>Mailing Lists</h1>

