<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - Moblie Devices';
$this->breadcrumbs=array(
	'Mobile Devices',
);
?>

<h1>Mobile Devices</h1>
