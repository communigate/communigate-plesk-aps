<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - Mailing List';
$this->breadcrumbs=array(
	'Mailing List',
);
?>

<h1>Mailing List</h1>