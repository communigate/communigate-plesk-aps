<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - VoIP';
$this->breadcrumbs=array(
	'VoIP',
);
?>

<h1>VoIP</h1>